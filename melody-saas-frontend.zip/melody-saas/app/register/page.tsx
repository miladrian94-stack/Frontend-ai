'use client'
import Link from 'next/link'
import { useState } from 'react'
import { register, googleLoginUrl, GOOGLE_CLIENT_ID } from '@/lib/api'

export default function RegisterPage() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (password.length < 8 || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
      setError('كلمة المرور: 8 أحرف على الأقل، وتحتوي على حرف كبير ورقم. مثال: Test1234')
      return
    }
    setLoading(true)
    try {
      await register(name, email, password)
      window.location.href = '/dashboard'
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'فشل إنشاء الحساب')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="auth-page">
      <div className="auth-card card">
        <div style={{textAlign:'center',marginBottom:24}}>
          <div style={{fontSize:32,marginBottom:8}}>🎵</div>
          <h1 style={{margin:'0 0 6px',fontSize:24,fontWeight:900}}>إنشاء حساب مجاني</h1>
          <p className="muted text-sm">ابدأ بـ 100 Credit مجاناً</p>
        </div>

        {GOOGLE_CLIENT_ID && (
          <>
            <button type="button" className="btn outline full"
              onClick={() => window.location.href = googleLoginUrl()}>
              <svg width="18" height="18" viewBox="0 0 24 24" style={{flexShrink:0}}>
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              المتابعة بـ Google
            </button>
            <div className="divider">أو</div>
          </>
        )}

        {error && <div className="error">{error}</div>}

        <form onSubmit={submit}>
          <div className="field">
            <label>الاسم</label>
            <input value={name} onChange={e => setName(e.target.value)}
              placeholder="اسمك الكامل" required minLength={2} />
          </div>
          <div className="field">
            <label>البريد الإلكتروني</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com" required />
          </div>
          <div className="field">
            <label>كلمة المرور</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)}
              placeholder="8 أحرف + حرف كبير + رقم" required minLength={8} />
          </div>
          <button className="btn full" disabled={loading}>
            {loading ? '⏳ جاري الإنشاء...' : '🚀 إنشاء حساب مجاني'}
          </button>
        </form>

        <p className="muted text-sm" style={{textAlign:'center',marginTop:18}}>
          لديك حساب؟{' '}
          <Link href="/login" style={{color:'#a5b4fc',fontWeight:600}}>تسجيل الدخول</Link>
        </p>
      </div>
    </main>
  )
}
